package enums;

public enum Brand {
FOODIE_PUPPPIES, FUTUREKART, PAYDEGREE;
}
