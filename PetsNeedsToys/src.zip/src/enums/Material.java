package enums;

public enum Material {
PLASTIC, RUBBER, WOOD;

}
